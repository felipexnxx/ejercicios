package conversiones;

import java.util.Scanner;

public class conversiones_libras {

	public static void main(String[] args) {
		// convertir de kilogramos a libras
		Scanner tc=new Scanner(System.in);
		int N;//cantidad en kilogramos
		System.out.println("Ingrese un valor");
        N=tc.nextInt();
        double Libra=N * 2.205;
		System.out.println("El valor de kilogramos a libras es:"+Libra);
	}
}
