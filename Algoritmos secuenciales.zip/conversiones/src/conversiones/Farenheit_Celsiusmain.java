package conversiones;

import java.util.Scanner;

public class Farenheit_Celsiusmain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);    
		double x; //Cant. dada en celsius
		System.out.println("Ingrese un valor");
		x=sc.nextDouble();
		double Fahrenheit= (x * 1.8)+ 32;
		System.out.println("El resuldo en Fahrenheit es:"+Fahrenheit);
	}

}
