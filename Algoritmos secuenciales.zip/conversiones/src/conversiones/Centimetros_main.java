package conversiones;

import java.util.Scanner;

public class Centimetros_main {

	public static void main(String[] args) {
		// Convertiremos yardas, pies y pulgadas a centimetros
		Scanner tc=new Scanner(System.in);
		int Y; //valor en yardas //1 yarda=91.44 cm
		int F; //valor en pies // 1 pie=30.48 cm
		int I; //valor en pulgadas //1 pulgada=2.54 cm
		double centimetro1, centimetro2, centimetro3;
	    System.out.println("Ingrese el valor");
	    Y=tc.nextInt();
	    F=tc.nextInt();
	    I=tc.nextInt();
	    centimetro1= Y * 91.44;
	    centimetro2= F * 30.48;
	    centimetro3= I * 2.54;
	    System.out.println("//*************************************************//");
	    System.out.println("La conversion de yardas a centimetros es:"+centimetro1);
	    System.out.println("//*************************************************//");

	    System.out.println("//**********************************************//");
	    System.out.println("La conversion de pies a centimetro es:"+centimetro2);
	    System.out.println("//**********************************************//");

	    System.out.println("//*************************************************//");
	    System.out.println("La conversion de pulgadas a centimetro es:"+centimetro3);
	    System.out.println("//*************************************************//");


	}

}
