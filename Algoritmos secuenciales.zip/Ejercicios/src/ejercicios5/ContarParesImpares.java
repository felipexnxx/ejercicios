package ejercicios5;

public class ContarParesImpares {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int suma;
int pares=0, impares=0;
for(int a=20; a<=100; a++) {
	if(a%2==0) {
	pares++;
}else {
	impares++;
	System.out.println("\nCantidad de numeros pares:"+pares);
	System.out.println("\nCantidad de numeros impares:"+impares);
}
	}
suma=pares+impares;
System.out.println("La suma de ellos es:"+suma);

	}
}
