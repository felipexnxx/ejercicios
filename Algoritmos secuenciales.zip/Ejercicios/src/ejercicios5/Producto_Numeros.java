package ejercicios5;

import java.util.Scanner;

public class Producto_Numeros {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   Scanner tc=new Scanner(System.in);
   int N;
   int A=0;
   int producto=0;
   System.out.println("Digite un numero");
   N=tc.nextInt();
   for(int i=1; i<=N; i++) {
	   System.out.println("Ingrese los numeros");
       A=tc.nextInt();
       A=A++;
       producto=(+A* +A*+A);
   }
   System.out.println("El producto de los numeros es:"+producto);

		   
	}

}
