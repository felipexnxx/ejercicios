package ejercicios5;

import java.util.Scanner;

public class NumeroEnteros {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 Scanner sc=new Scanner(System.in);
 int n;
 int x=0;
 System.out.println("Ingrese un numero");
n=sc.nextInt();
 for(int i=0; i<=n; i++) {
	 System.out.println("Digite los numeros");
	 x=sc.nextInt();
	 x=x++;
	 System.out.println(+x);

 }

	}

}
