package ejercicios5;

import java.util.Scanner;

public class XY {


	public static void main(String[] args) {
		// TODO Auto-generated method stub
 Scanner teclado=new Scanner(System.in);
 int X, Y;
 int Suma=0, Resta=0, Division=0, suma=0;
 double Raiz=0;
 System.out.println("Ingrese los numeros");
 X=teclado.nextInt();
 Y=teclado.nextInt();
if(X<0 && Y<0) {
	 Suma=X + Y;
 }else {
	 Resta=X + Y;
 }
System.out.println("La suma es:"+Suma);
System.out.println("La resta es:"+Resta);

 if(X>0 && Y<0) {
	 Division=X/Y;    
 }else if(X>Y){
	 suma=X + Y;
 }else {
	 Raiz=Math.sqrt(X);
 }
 System.out.println("La division es:"+Division);
 System.out.println("La suma="+suma);
 System.out.println("La raiz cuadrada es:"+Raiz);


	}

}
