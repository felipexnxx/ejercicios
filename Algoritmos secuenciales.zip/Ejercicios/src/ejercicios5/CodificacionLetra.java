package ejercicios5;

import java.util.Scanner;

public class CodificacionLetra {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner teclado=new Scanner(System.in);
int numero;

System.out.println("Ingrese la nota");
numero=teclado.nextInt();
if(numero>=90) {
	System.out.println("Su calificación es A");
}
if(numero>=80 && numero<90) {
	System.out.println("Su calificación es B");
}
if(numero>70 && numero<80) {
	System.out.println("Su calificación es C");
}
if(numero>65 && numero<70){
	System.out.println("Su calificación es D");
}
if(numero<65) {
	System.out.println("Su calificación es E");

}
	}

}
