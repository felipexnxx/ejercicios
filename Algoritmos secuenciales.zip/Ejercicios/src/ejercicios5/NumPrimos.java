package ejercicios5;

import java.util.Scanner;

public class NumPrimos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 Scanner tc=new Scanner(System.in);
 int x;
 System.out.println("Escriba un numero");
 x=tc.nextInt();
 for(int i=1; i<=x; i++) {
	 if(x%i==1) {
		 System.out.println("El numero es primo");
		 
	 }else if(x%2==0) {
		 System.out.println("El numero no es primo");
	 }
 }
	}

}
