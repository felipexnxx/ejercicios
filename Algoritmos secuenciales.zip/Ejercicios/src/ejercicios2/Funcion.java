package ejercicios2;

import java.util.Scanner;

public class Funcion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner leer=new Scanner(System.in);
double m=5,n=2,p=3;
double Y, x;
System.out.println("Ingrese el valor siguiente:");
System.out.println("x=");
x=leer.nextDouble();
System.out.println("m="+m);
System.out.println("o="+n);
System.out.println("p="+p);

Y=Math.pow(m*x, 4) + Math.pow(n*x, 3) + Math.pow(p*x, 2) +7;
System.out.println("El valor de la funcion Y es:"+Y);
	}

}
