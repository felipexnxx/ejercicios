package ejercicios2;

import java.util.Scanner;

public class edadvotante {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Scanner teclado=new Scanner(System.in);
     int edad;
     System.out.println("INGRESE SU EDAD");
     edad=teclado.nextInt();
     if(edad>=18) {
    	 System.out.println("Usted ya puede votar");
     }else {
    	 System.out.println("Usted no puede votar.Es menor de edad");

     }
	}

}
