package ejercicios2;

import java.util.Scanner;

public class Negativo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc=new Scanner(System.in);
    double X;
    System.out.println("Escriba un número");
    X=tc.nextInt();
    if(X<0){
        System.out.println("Es un numero negativo");
        X=Math.pow(X, 4);
        System.out.print(X);

    }else {
    	if(X>0) {
    		System.out.println("El numero es positivo");
    		X=Math.pow(X, 2);
    	    System.out.print(X);
    	}	
      }
    }
	}


