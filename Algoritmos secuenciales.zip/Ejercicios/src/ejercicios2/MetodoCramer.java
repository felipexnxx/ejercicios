package ejercicios2;

import java.util.Scanner;

public class MetodoCramer {

	public static void main(String[] args) {
		//Ecuaciones de sistema ax+by=c y dx+ey=f
Scanner sc=new Scanner(System.in);
double a,b,c,d,e,f;
double x, y;
System.out.println("INGRESE LOS VALORES");
System.out.println("a");
a=sc.nextDouble();
System.out.println("b");
b=sc.nextDouble();
System.out.println("c");
c=sc.nextDouble();
System.out.println("d");
d=sc.nextDouble();
System.out.println("e");
e=sc.nextDouble();
System.out.println("f");
f=sc.nextDouble();

x=(c*e - b*f)/(a*e - b*d);
y=(a*f - c*d)/(a*e - b*d);
System.out.println("El resulatdo del sistema es:");
System.out.println("x="+x);
System.out.println("y="+y);

	}

}
