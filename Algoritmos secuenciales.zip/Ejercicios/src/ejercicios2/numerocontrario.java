package ejercicios2;

import java.util.Scanner;

public class numerocontrario {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
    int n;
    int invertido=0, resto;
    System.out.println("Ingrese un número solo de 3 cifras");
    n=sc.nextInt();
    while(n>0) {
    	resto=n%10;
    	invertido=invertido*10+resto;
    	n/=10;
      }
    System.out.println("Numero invertido:"+invertido);
	}

}
