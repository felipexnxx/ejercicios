package ejercicios2;

import java.util.Scanner;

public class ParImpar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Scanner tc=new Scanner(System.in);
    int num;
    System.out.println("Ingrese un numero");
    num=tc.nextInt();
    if(num%2==0) {
        System.out.println("Este numero es par");
    }else {
        System.out.println("Este numero es impar");
    }
	}

}
