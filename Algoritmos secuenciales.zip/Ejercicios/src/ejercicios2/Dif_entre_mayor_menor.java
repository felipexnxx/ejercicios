package ejercicios2;

import java.util.Scanner;

public class Dif_entre_mayor_menor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
int a, b;
int diferencia;
System.out.println("Ingrese dos numeros enteros");
a=sc.nextInt();
b=sc.nextInt();
diferencia=a - b;
System.out.println("La diferencia entre ambos numeros es:"+diferencia);


	}

}
