package ejercicios4;

public class Num_1al100 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    int count=0;
    for(int i=0; i<=99; i++) {
    	count=count+1;
    	System.out.println(count);

    }
	}

}
