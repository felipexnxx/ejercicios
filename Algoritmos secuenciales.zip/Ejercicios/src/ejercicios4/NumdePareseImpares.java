package ejercicios4;

import java.util.Scanner;

public class NumdePareseImpares {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   Scanner sc=new Scanner(System.in);
   int n, a=0;
   System.out.println("Ingrese un número");
   n=sc.nextInt();
   for(int j=1; j<=n; j++) {
	   System.out.println("Digite un número cualquiera");
	   a=a+j;
       a=sc.nextInt();
       if(a%2==0) {
    	   System.out.println("Es par");
       }else {
    	   System.out.println("Es impar");

      
             }
   }
   }
	}


