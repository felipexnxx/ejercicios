package ejercicios4;

import java.util.Scanner;

public class Ndistintosde0 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner teclado=new Scanner(System.in);
int N, A=0;
System.out.println("Ingrese una cantidad");
N=teclado.nextInt();
for(int k=0; k<=N; k++) {
	System.out.println("Ingrese los numeros");
    A=teclado.nextInt();
    A=A+k;

if(A>0) {
	System.out.println("Es positivo");  
}else {		
System.out.println("Es negativo");
System.out.println(A);
	}
	}
}
	}


