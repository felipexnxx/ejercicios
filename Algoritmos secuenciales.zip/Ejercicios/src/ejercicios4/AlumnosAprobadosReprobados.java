package ejercicios4;

import java.util.Scanner;

public class AlumnosAprobadosReprobados {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Scanner teclado=new Scanner(System.in);
    int alumnos;
    int notas=0;
    System.out.println("Ingrese la cantidad de alumnos");
    alumnos=teclado.nextInt();
    for(int i=1; i<=alumnos; i++) {
        System.out.println("Ingrese las nota del alumno");
        notas=teclado.nextInt();
        notas=notas+i;
        if(notas>60) {
            System.out.println("El alumno esta aprobado");
        }else {
            System.out.println("El alumno esta desaprobado");
        }
      }
    }
}


