package ejercicios4;

import java.util.Scanner;

public class Promedio_de_Nnumeros {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Scanner tc=new Scanner(System.in);
    int num, suma=0, x;
    double promedio=0;
    System.out.println("Ingrese la cantidad de numeros");
    x=tc.nextInt();
    
    for(int i=0; i<x; i++) {
    System.out.println("Ingrese los números");
    num=tc.nextInt();
    num=num+i;
    suma=suma+num;
	}
  promedio=suma/x;
  System.out.println("El promedio de los numeros:"+promedio);
}
}
