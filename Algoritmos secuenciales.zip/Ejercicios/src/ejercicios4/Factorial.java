package ejercicios4;

import java.util.Scanner;

public class Factorial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 Scanner tc=new Scanner(System.in);
 int Num;
 double factorial=1;
 
 do {
	 System.out.println("Escriba un numero");
     Num=tc.nextInt();
	 
 }while(Num<0);
 for(int i=1; i<=Num; i++) {
	 factorial=factorial * i;
 }
 System.out.println("El factorial es:"+factorial);
	
 }
	}

