package ejercicios;

import java.util.Scanner;

public class Pantalones {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner tc=new Scanner(System.in);
double CostoTotal;
int pantalones;
System.out.println("Ingrese la cantidad de pantalones que desea comprar");
pantalones=tc.nextInt();
if(pantalones>3) {
	System.out.println("El precio de los pantalones le sale a $10 cada uno");
	CostoTotal=pantalones * 10;
	System.out.println("El costo total a pagar seria de:"+CostoTotal);

}else {
	System.out.println("El precio de los pantalones le sale a $12 cada uno");
	CostoTotal=pantalones * 12;
	System.out.println("El costo total a pagar seria de:"+CostoTotal);

}
	}

}
