package ejercicios;

import java.util.Scanner;

public class RaizCuadrada {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc=new Scanner(System.in);
    int Num;
    System.out.println("Ingrese un número");
    Num=tc.nextInt();
    double Raíz=Math.sqrt(Num);
    System.out.println("La raíz cuadrada es="+Raíz);
	}
}