package ejercicios;

import java.util.Scanner;

public class SolucionLineal {

	public static void main(String[] args) {
//Ecuacion lineal de la forma ax+b=0
Scanner tc=new Scanner(System.in);
double a, b,x;
System.out.println("Ingrese el valor de a");
a=tc.nextDouble();
System.out.println("Ingrese el valor de b");
b=tc.nextDouble();

x=-b/a;
System.out.println("El valor de x:"+x);

	}

}
