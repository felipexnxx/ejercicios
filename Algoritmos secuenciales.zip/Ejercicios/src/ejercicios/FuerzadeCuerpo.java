package ejercicios;

import java.util.Scanner;

public class FuerzadeCuerpo {

	public static void main(String[] args) {
		// Calcular la fuerza de un cuerpo
		Scanner teclado=new Scanner(System.in);
    int M, A; //Masa y Aceleracion
    int Fuerza;
    System.out.println("Ingrese la masa del cuerpo en kg");
    M=teclado.nextInt();
    System.out.println("Ingrese la aceleración del cuerpo en m/s");
    A=teclado.nextInt();
    Fuerza= M * A;
    System.out.println("La fuerza del cuerpo es="+Fuerza);
	}
}
