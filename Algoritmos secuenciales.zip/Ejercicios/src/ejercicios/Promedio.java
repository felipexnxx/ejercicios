package ejercicios;

import java.util.Scanner;

public class Promedio {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Scanner teclado=new Scanner(System.in);
    int notas,N,suma=0;
    double promedio=0;
    System.out.println("Ingrese una cantidad");
    N=teclado.nextInt();  
    for(int i=1; i<=N; i++) {
        System.out.println("Ingrese las notas"+i+":");
        notas=teclado.nextInt();
        suma=suma +notas;
    }
    promedio=suma/N;
    System.out.println("El promedio:"+promedio);

	}
}
