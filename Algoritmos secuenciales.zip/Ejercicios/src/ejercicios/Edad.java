package ejercicios;

import java.util.Scanner;

public class Edad {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 Scanner sc=new Scanner(System.in);
 int edad;
 System.out.println("Ingrese su edad");
 edad=sc.nextInt();
 if(edad<13) {
	 System.out.println("Es niño"); 
 }else if(edad>13 && edad<=25) {
	 System.out.println("Es joven");
 }else {
	 if(edad>25) {
		 System.out.println("Es adulto");
	 }
 }
 
	}

}
