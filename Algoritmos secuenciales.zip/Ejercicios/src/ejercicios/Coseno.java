package ejercicios;

import java.util.Scanner;

public class Coseno {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
    int num;
    double Coseno;
    System.out.println("Ingrese un número cualquiera");
    num=sc.nextInt();
    Coseno=Math.cos(num);
    System.out.println("El coseno es="+Coseno);

	}

}
