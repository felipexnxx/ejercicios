package ejercicios3;

import java.util.Scanner;

public class Aprobado_Reprobado {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Scanner teclado=new Scanner(System.in);
    String alumno;
    int notas;
    System.out.println("Escriba el nombre del alumno");
    alumno=teclado.next();
    System.out.println("Escriba la nota final");
    notas=teclado.nextInt();
    if(notas>=60) {
        System.out.println("Esta aprobado");
    }else if(notas<60){
        System.out.println("Esta reprobado");
      }
   }
}
