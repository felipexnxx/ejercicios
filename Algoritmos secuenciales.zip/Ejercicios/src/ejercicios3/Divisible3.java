package ejercicios3;

import java.util.Scanner;

public class Divisible3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Scanner teclado=new Scanner(System.in);
    int número;
    System.out.println("Ingrese un número");
    número=teclado.nextInt();
    if(número%3==0) {
    	System.out.println("El número es divisible entre 3");

    }else {
    	System.out.println("El número no es divisible entre 3");
    }
	}
}
