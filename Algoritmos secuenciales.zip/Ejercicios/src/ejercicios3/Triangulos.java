package ejercicios3;

import java.util.Scanner;

public class Triangulos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Scanner teclado=new Scanner(System.in);
    int a, b, c;
    
    do {
    	System.out.println("Ingrese el lado#1");
        a=teclado.nextInt();
        System.out.println("Ingrese el lado#2");
        b=teclado.nextInt();
        System.out.println("Ingrese el lado#3");
        c=teclado.nextInt();
    }
    while(a<=0 || b<=0 || c<=0);
    if(a==b && b==c) {
    	System.out.println("Es equilatero");
    }
    else if(a==b || b==c || a==c) {
    	System.out.println("Es iszoceles");
    }
    else {
    	System.out.println("Es escaleno");
    }
	}
}
