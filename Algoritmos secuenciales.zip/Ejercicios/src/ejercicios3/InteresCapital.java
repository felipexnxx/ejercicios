package ejercicios3;

import java.util.Scanner;

public class InteresCapital {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
    double capital, interes=0;
    System.out.println("Ingrese el capital prestado");
    capital=sc.nextFloat();
    if(capital>10000) {
    	interes=(capital * 0.07);
        System.out.println("/**************/");
        System.out.println("Capital="+capital);
        System.out.println("/**************/");
        System.out.println("Interes="+interes);
        System.out.println("/**************/");

    }else {
    	if(capital<10000) {
    		interes=(capital * 0.06);
    		 System.out.println("/**************/");
    	     System.out.println("Capital="+capital);
    	     System.out.println("/**************/");
    	     System.out.println("Interes="+interes);
    	     System.out.println("/**************/");
    	}
      }
	}
}
