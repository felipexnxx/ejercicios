package ejercicios3;

import java.util.Scanner;

public class ValorY {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner tc=new Scanner(System.in);
double Y=0;
int A;
System.out.println("Ingrese un número");
A=tc.nextInt();
if(A>0) {
	System.out.println("Es un número positivo");
	Y=Math.pow(2, A);
	System.out.println("El resulatdo es:"+Y);

}else {
	System.out.println("Es un número negativo");
    Y=A + 5;
    System.out.println("El resultado es:"+Y);
   }
 }

}
