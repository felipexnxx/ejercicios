package ejercicios3;

import java.util.Scanner;

public class Leernumeros {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner teclado=new Scanner(System.in);
int numeros;
for(int i=0; i<=20; i++) {
	System.out.println("Ingrese los números");
	numeros=teclado.nextInt();
	numeros=numeros+i;
	if(numeros==0) {
		System.out.println("Igual a cero/nulo");
	}else {
		if(numeros>0) {
			System.out.println("Positivo");
		}else {
			System.out.println("Negativo");
		}
	}
}
	}

}
