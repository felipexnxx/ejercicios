package ejercicios3;

import java.util.Scanner;

public class SignosOpuestos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner teclado=new Scanner(System.in);
int x, y;
int opuesto=0;
System.out.println("Ingrese dos números enteros");
x=teclado.nextInt();
y=teclado.nextInt();
if(x>0) {
	System.out.println("POSITIVO"+x);
	opuesto=-(x);
}else if(x<0) {
	System.out.println("NEGATIVO"+x);
    opuesto=-(x);
}
System.out.println("El opuesto del numero es:"+opuesto);

if(y>0) {
	System.out.println("POSITIVO"+y);
    opuesto=-(y);
}else if(y<0) {
	System.out.println("NEGATIVO"+y);
    opuesto=-(y);
}
System.out.println("El opuesto del numero es:"+opuesto);

}

}
	


