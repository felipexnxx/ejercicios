package Volumen;

import java.util.Scanner;

public class VolumenCilindro {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Scanner tc= new Scanner(System.in);
    double radio, altura;
    double Volumen;
    System.out.println("Ingrese el radio");
    radio=tc.nextDouble();
    System.out.println("Ingrese la altura");
    altura=tc.nextDouble();
    Volumen= Math.PI*Math.pow(radio,2)*altura;
    System.out.println("El volumen del cilindro es:"+Volumen);

	}

}
