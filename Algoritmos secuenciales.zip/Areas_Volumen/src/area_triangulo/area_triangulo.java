package area_triangulo;

import java.util.Scanner;

public class area_triangulo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int Base, Altura;
		int Area=0;
     System.out.println("Ingrse la base");
       Base=sc.nextInt();
       System.out.println("Ingrese la altura");
       Altura=sc.nextInt();
       Area= Base * Altura/2;
       System.out.println("El area del triangulo es:"+Area);

	}

}
