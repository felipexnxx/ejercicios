
package area_circulo;

import java.util.Scanner;
public class main {

	public static void main(String[] args) {
		// Sirve para calcular area del circulo
		
		int Radio;
		
		
		System.out.println("Ingrese el valor del radio");
		Scanner radio=new Scanner(System.in);
        Radio=radio.nextInt();
        double Area=Math.PI * Math.pow(Radio,2);
		double Perimetro=2*Math.PI * Radio;
		System.out.println("El area del circulo es:"+Area);
		System.out.println("El perimetro del circulo es:"+Perimetro);
	}
}
