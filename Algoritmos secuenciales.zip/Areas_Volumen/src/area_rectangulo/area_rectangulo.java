package area_rectangulo;

import java.util.Scanner;
public class area_rectangulo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Scanner sc= new Scanner(System.in);
    double Area=0;
    double B,H;
    
    System.out.println("Ingrese la base");
    B=sc.nextDouble();
    System.out.println("Ingrese la altura");
    H=sc.nextDouble();
    Area=B*H;
    System.out.println("El area del rectangulo es:"+Area);
	}

}
